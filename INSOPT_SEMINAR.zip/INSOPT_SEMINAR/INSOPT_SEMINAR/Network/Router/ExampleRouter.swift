//
//  ExampleRouter.swift
//  INSOPT_SEMINAR
//
//  Created by hansol on 2022/11/05.
//

import Foundation
import UIKit

import Moya

enum ExampleRouter {
    case fetchProfileV1(userID: Int)
    case fetchProfileV2(userID: Int)
    case fetchEvent(param: EventRequestDto)
}

extension ExampleRouter: TargetType {
    var baseURL: URL {
        return URL(string: Environment.baseURL)!
    }
    
    var path: String {
        switch self {
      
        case .fetchProfileV1(userID: let userID):
            return "/user/\(userID)"
        case .fetchProfileV2(userID: _):
            return "/user"
        case .fetchEvent(param: _):
            return "/event"
        }
    }
    
    var method: Moya.Method {
        switch self {
       
        case .fetchProfileV1(userID: _):
            return .get
        case .fetchProfileV2(userID: _):
            return .get
        case .fetchEvent(param: _):
            return .get
        }
    }
    
    var task: Task {
        switch self {
        
        case .fetchProfileV1(userID: _):
            return .requestPlain
        case .fetchProfileV2(userID: let userID):
            let param = ["userId": userID]
            return .requestParameters(
                parameters: try! param.asParameter(),
                encoding: URLEncoding(destination: .queryString,
                                      arrayEncoding: .noBrackets)
            )
        case .fetchEvent(param: let param):
            let bodyParam = param.date
            let urlParam = ["userId": param.userId]
            return .requestCompositeParameters(
                bodyParameters: try! bodyParam.asParameter(),
                bodyEncoding: JSONEncoding.default,
                urlParameters: try! urlParam.asParameter()
            )
        }
    }
    
    var headers: [String : String]? {
        return ["Content-Type": "application/json"]
    }
}


//
//  KakaoFriendModel.swift
//  INSOPT_SEMINAR
//
//  Created by hansol on 2022/10/22.
//

import Foundation
import UIKit

struct KakaoFriendModel {
    let profileImage: String
    let name: String
    let message: String
}

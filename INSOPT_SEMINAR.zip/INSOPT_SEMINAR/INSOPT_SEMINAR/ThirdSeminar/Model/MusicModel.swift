//
//  MusicModel.swift
//  INSOPT_SEMINAR
//
//  Created by hansol on 2022/10/15.
//

import Foundation

struct MusicModel {
    let albumImage: String
    let title: String
    let singer: String
}
